#!/usr/bin/env bash

if [ $# -lt 1 ] ; then
    echo "usage: $(basename $0) PROPS_FILE [ARGS]" >&2
    exit 2
fi

source funcs.sh $1
shift

setCP || exit 1

java -server -Xms4g -Xmx4g -cp "$myCP" -Dprop=$PROPS LoadData $*
